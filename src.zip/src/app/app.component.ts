import { Component, ElementRef } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  ngOnInit () {
    this.dropdownList = [
      {
        "Countries": [
          { item_id: 1, item_text: 'India' },
          { item_id: 2, item_text: 'United States of America' },
          { item_id: 3, item_text: 'Sri Lanka' },
          { item_id: 4, item_text: 'Australia' },
          { item_id: 5, item_text: 'China' }
        ]
      },
      {
        "AddressType": [
          {
            item_id: 1, item_text: 'RMA'
          },
          {
            item_id: 2, item_text: 'TMA'
          }
        ]
      },
      {
        "MatchCategory": [
          {
            item_id: 1, item_text: 'All'
          },
          {
            item_id: 2, item_text: 'Some'
          }
        ]
      }
    ];
    this.selectedItems = [];
    this.dropdownSettings = {
      singleSelection: true,
      idField: 'item_id',
      textField: 'item_text',
      enableSelectAll: false,
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
  }
  onItemSelect (item:any) {
    console.log(item);
  }
}

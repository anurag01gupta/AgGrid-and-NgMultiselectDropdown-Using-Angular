import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-case-tile',
  templateUrl: './case-tile.component.html',
  styleUrls: ['./case-tile.component.scss']
})
export class CaseTileComponent implements OnInit {
  @Input('casetile') casetile: any;
  constructor() { }

  ngOnInit() {
  }

}
